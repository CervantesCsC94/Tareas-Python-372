from django.db import models
from django.conf import settings
# Create your models here.


class Autor(models.Model):
	nombre=models.CharField(max_length=50)

	def __str__(self):
		return self.nombre

class Categoria(models.Model):
	categoria=models.CharField(max_length=50)	

	def __str__(self):
		return self.categoria		


class documento(models.Model):
	titulo=models.CharField(max_length=100)
	autor=models.ForeignKey(Autor, null=True, blank=True, on_delete=models.CASCADE)
	categoria=models.ForeignKey(Categoria, null=True, blank=True, on_delete=models.CASCADE)
	timestap=models.DateTimeField(auto_now_add=True)
	update=models.DateTimeField(auto_now_add=True)
	media=models.FileField(upload_to="My_media",blank=True, null=True)
	contenido=models.TextField(blank=True)
	
	def __str__(self):
		return self.titulo

