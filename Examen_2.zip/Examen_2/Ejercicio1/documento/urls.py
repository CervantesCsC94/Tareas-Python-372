from django.contrib import admin
from django.urls import path

from documento import views
app_name="documento"

urlpatterns = [
	#path('',views.index, name="index_view"),
	path('create/',views.Create.as_view(), name="create_view"),
	#path('create/',views.documentos, name="create_view"),
	path('',views.Categorias.as_view(),name="categorias_view"),
	#path('lista_trabajo/<int:pk>',views.ListaTrabajos.as_view(),name="trabajos_view"),
	path('lista_trabajos/<int:id>',views.lista_trabajos,name="trabajo_view"),
	path('detail_trabajos/<int:pk>',views.DetailTrabajo.as_view(),name="detail_view"),
	
]