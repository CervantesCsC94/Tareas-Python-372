from django.shortcuts import render
from .forms import FormCreate
from django.views import generic
from .models import documento,Categoria,Autor

# Create your views here.

def index(request):
	
	return render(request,"documento/index.html",{})

class Categorias(generic.ListView):
	template_name="documento/categorias.html"
	model=Categoria


def documentos(request):
 	form=FormCreate(request.POST or None, request.FILES or None)
 	if request.POST:
 		if form.is_valid():
 			form.save()	
 	else:
 		form=FormCreate(request.POST or None)	

 	contex={"form":form}
 	return render(request,"documento/create.html",contex)

class ListaTrabajos(generic.ListView):
	template_name="documento/lista_Trabajos.html"
	model=documento

def lista_trabajos(request,id=1):
	queryset1=Categoria.objects.get(id=id)	
	queryset2=documento.objects.all()
	contex={"documento":queryset1,"documentos":queryset2}
	return render(request,"documento/lista_Trabajos.html",contex)

class DetailTrabajo(generic.DetailView):
	template_name="documento/detail_trabajo.html"
	model=documento

class Create(generic.CreateView):
 	template_name="documento/create.html"
 	#orm_class=FormCreate
 	model=documento
 	fields=["titulo","autor","categoria","media","contenido"]
 	success_url="/"