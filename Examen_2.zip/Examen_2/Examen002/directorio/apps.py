from django.apps import AppConfig


class DirectorioConfig(AppConfig):
    name = 'directorio'
