from django.contrib import admin
from django.urls import path
from directorio import views

app_name="directorio"

urlpatterns = [
	path('',views.software_list.as_view(),name="softwareList"),
	path('delete/<int:pk>',views.delete_software.as_view(), name="delete_view"),
	path('update/<int:pk>',views.editar_software.as_view(), name="update_view"),
	path('createSoftware/',views.crear_software.as_view(),name="createS_view"),
	path('createDepartamento/',views.crear_departamento.as_view(),name="createD_view"),

]