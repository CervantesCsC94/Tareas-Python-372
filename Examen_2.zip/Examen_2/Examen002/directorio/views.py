from django.shortcuts import render
from .models import *
from django.views import generic
from .form import *
# Create your views here.

class software_list(generic.ListView):
	template_name='directorio/softwareList.html'
	model=Software

class delete_software(generic.DeleteView):
	template_name='directorio/deleteSoftware.html'
	model=Software
	success_url="/"

class editar_software(generic.UpdateView):
	template_name='directorio/updateSoftware.html'
	model=Software
	form_class=SoftwareForm
	success_url="/"

class crear_software(generic.CreateView):
	template_name="directorio/createSoftware.html"
	form_class=SoftwareForm
	model=Software
	success_url="/"

class crear_departamento(generic.CreateView):
	template_name="directorio/createDepartamento.html"
	form_class=DepartamentoForm
	model=Departamento
	success_url="/"